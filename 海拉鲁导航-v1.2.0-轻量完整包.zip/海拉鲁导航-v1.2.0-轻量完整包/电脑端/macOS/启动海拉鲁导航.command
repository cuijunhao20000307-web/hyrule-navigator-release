#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROGRAM_DIR="$(cd "$SCRIPT_DIR/../程序文件" && pwd)"
if [ ! -f "$PROGRAM_DIR/package.json" ]; then
  echo "[错误] 找不到‘程序文件’目录，请重新解压整个压缩包。"
  read -r "?按回车键关闭窗口..."
  exit 1
fi
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "[错误] 请先安装 Node.js 22 或更高版本。"
  read -r "?按回车键关闭窗口..."
  exit 1
fi
cd "$PROGRAM_DIR"
if [ ! -d node_modules ]; then
  echo "首次启动，正在安装运行依赖……"
  npm ci
fi
(sleep 4; open http://localhost:3000 >/dev/null 2>&1) &
echo "海拉鲁导航正在启动：http://localhost:3000"
npm run dev -- --hostname 0.0.0.0
