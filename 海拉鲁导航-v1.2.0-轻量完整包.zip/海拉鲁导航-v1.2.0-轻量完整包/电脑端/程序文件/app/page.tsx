"use client";

import { useEffect, useMemo, useRef, useState, type CSSProperties, type MouseEvent as ReactMouseEvent } from "react";
import referenceMarkers from "./hyrule-markers.json";
import teleportTargetData from "./teleport-targets.json";

type Kind = "神庙" | "塔" | "村落" | "马宿" | "大精灵" | "神兽" | "地点" | "呀哈哈" | "记忆" | "任务" | "首领" | "守护者" | "敌人营地" | "可破坏墙" | "武器" | "弓箭" | "盾牌" | "盔甲" | "食材" | "材料";
type Point = {
  id: number;
  name: string;
  region: string;
  kind: Kind;
  x: number;
  y: number;
  note: string;
  teleport?: {
    x: number;
    y: number;
    z: number;
    source: "terrain";
  };
};
type VoiceLanguage = "zh-CN" | "ja-JP";
type TeleportPhase = "idle" | "sending" | "pending" | "confirmed" | "executing" | "succeeded" | "failed" | "cancelled" | "expired";
type TeleportFeedback = {
  phase: TeleportPhase;
  message: string;
  requestId?: number;
  pointId?: number;
};
type TeleportCoordinates = {
  id: number;
  x: number;
  y: number;
  z: number;
  source: string;
};

const points: Point[] = [
  { id: 1, name: "初始之塔", region: "初始台地", kind: "塔", x: 45.507, y: 67.005, note: "解锁初始台地区域地图。" },
  { id: 2, name: "玛·奥努神庙", region: "初始台地", kind: "神庙", x: 44.574, y: 65.188, note: "磁力之力试炼。" },
  { id: 3, name: "瓦哥·卡塔神庙", region: "海拉鲁平原", kind: "神庙", x: 53.092, y: 60.126, note: "金属连接试炼。" },
  { id: 4, name: "卡卡利科村", region: "西哈特尔", kind: "村落", x: 65.311, y: 59.896, note: "拜访英帕并补充箭矢与料理素材。" },
  { id: 5, name: "哈特诺村", region: "东哈特尔", kind: "村落", x: 80.261, y: 71.276, note: "古代研究所位于村子东侧高处。" },
  { id: 6, name: "双子山之塔", region: "西哈特尔", kind: "塔", x: 58.708, y: 67.195, note: "解锁哈特尔区域地图。" },
  { id: 7, name: "丘陵之塔", region: "海拉鲁丘陵", kind: "塔", x: 35.515, y: 42.291, note: "塔身四周有电系威胁。" },
  { id: 8, name: "拉聂尔之塔", region: "拉聂尔", kind: "塔", x: 69.093, y: 48.949, note: "通往卓拉领地的观察点。" },
  { id: 11, name: "海利亚盾", region: "海拉鲁城堡", kind: "盾牌", x: 50, y: 39, note: "城堡地下牢房区域的宝箱装备。" },
  { id: 12, name: "近卫之剑", region: "海拉鲁城堡", kind: "武器", x: 51, y: 36, note: "城堡内部可取得的近卫系列武器。" },
  { id: 13, name: "近卫之弓", region: "海拉鲁城堡", kind: "弓箭", x: 53, y: 37, note: "留意城堡内部高处与武器架。" },
  { id: 14, name: "蛮族头盔", region: "洛美岛", kind: "盔甲", x: 91, y: 17, note: "完成洛美岛迷宫后取得。" },
  { id: 15, name: "蛮族服", region: "南洛美城堡遗迹", kind: "盔甲", x: 29, y: 86, note: "完成南洛美迷宫挑战后取得。" },
  { id: 16, name: "蛮族短裤", region: "北洛美城堡遗迹", kind: "盔甲", x: 34, y: 11, note: "完成北洛美迷宫挑战后取得。" },
  { id: 17, name: "雷电大剑", region: "塔邦挞边境", kind: "武器", x: 22, y: 37, note: "山地宝箱中的属性武器。" },
  { id: 18, name: "火焰大剑", region: "奥尔汀峡谷", kind: "武器", x: 67, y: 21, note: "高温地区常见的属性武器。" },
  { id: 19, name: "冰雪大剑", region: "海布拉山脉", kind: "武器", x: 19, y: 18, note: "雪山区域可重复寻找的属性武器。" },
  { id: 20, name: "古代兵装·剑", region: "阿卡莱古代研究所", kind: "武器", x: 89, y: 29, note: "可在古代研究所制作。" },
  { id: 21, name: "古代兵装·弓", region: "阿卡莱古代研究所", kind: "弓箭", x: 91, y: 30, note: "准备古代材料后制作。" },
  { id: 22, name: "古代兵装·盾", region: "阿卡莱古代研究所", kind: "盾牌", x: 89, y: 32, note: "可自动反射部分守护者光束。" },
  { id: 23, name: "卓拉之盾", region: "卓拉领地", kind: "盾牌", x: 80, y: 42, note: "卓拉领地周边的固定装备点。" },
  { id: 24, name: "游隼弓", region: "利特村", kind: "弓箭", x: 20, y: 30, note: "利特村附近可取得的轻量弓。" },
  { id: 25, name: "格鲁德之弓", region: "格鲁德小镇", kind: "弓箭", x: 32, y: 80, note: "格鲁德地区的远距离弓。" },
  { id: 26, name: "耐火石盔", region: "鼓隆城", kind: "盔甲", x: 69, y: 27, note: "在鼓隆城商店购买，适合火山探索。" },
  { id: 27, name: "潜行紧身服", region: "卡卡利科村", kind: "盔甲", x: 68, y: 59, note: "在卡卡利科村服装店购买。" },
  { id: 28, name: "沙地靴", region: "格鲁德小镇", kind: "盔甲", x: 34, y: 78, note: "完成格鲁德地区相关支线后取得。" },
  { id: 29, name: "兽神剑", region: "雷兽山", kind: "武器", x: 82, y: 39, note: "强敌掉落装备，属性会随游戏进度变化。" },
  { id: 30, name: "兽神弓", region: "海布拉雪原", kind: "弓箭", x: 28, y: 13, note: "人马掉落的多连发弓。" },
];

const allPoints: Point[] = [...points, ...(referenceMarkers as Point[])];
const icons: Record<Kind, string> = { 神庙: "◇", 塔: "♜", 村落: "⌂", 马宿: "♞", 大精灵: "❀", 神兽: "◆", 地点: "•", 呀哈哈: "✦", 记忆: "◉", 任务: "!", 首领: "☠", 守护者: "⦿", 敌人营地: "⚑", 可破坏墙: "▧", 武器: "⚔", 弓箭: "➶", 盾牌: "⬙", 盔甲: "♙", 食材: "♨", 材料: "◈" };
const equipmentKinds: Kind[] = ["武器", "弓箭", "盾牌", "盔甲"];
const locationKinds: Kind[] = ["神庙", "塔", "村落", "马宿", "大精灵", "神兽", "地点"];
const explorationKinds: Kind[] = ["呀哈哈", "记忆", "任务", "首领", "守护者", "敌人营地", "可破坏墙"];
const resourceKinds: Kind[] = ["食材", "材料"];
const tileBounds = {
  left: (34.25 / 256) * 100,
  right: (221 / 256) * 100,
  top: (49.875 / 256) * 100,
  bottom: (206 / 256) * 100,
};
const worldMapCalibration = {
  xScale: 0.0083668005,
  xOffset: 50.2008033,
  zScale: 0.0100080063,
  zOffset: 50.0400322,
};
const initialTowerSample = {
  map: { x: 45.507085, y: 67.005104 },
  world: { x: -560.9931640625, y: 246.42724609375, z: 1695.1500244140625, yaw: 0 },
};
const landmarkTeleportTargets = new Map<number, TeleportCoordinates>(
  (teleportTargetData.targets as TeleportCoordinates[]).map((target) => [target.id, target]),
);
const regionLabels = [
  ["海布拉", 20, 16], ["塔邦挞", 22, 34], ["海拉鲁丘陵", 36, 39],
  ["海拉鲁平原", 49, 57], ["海拉鲁城堡", 50, 38], ["奥尔汀", 68, 23],
  ["阿卡莱", 86, 28], ["拉聂尔", 76, 45], ["西哈特尔", 62, 63],
  ["东哈特尔", 79, 68], ["费罗尼", 60, 83], ["格鲁德高地", 24, 65],
  ["格鲁德沙漠", 31, 84], ["初始台地", 45, 68],
] as const;

const legendaryMarkers = [
  { name: "神兽·瓦梅德", icon: "◆", x: 18, y: 29, type: "beast" },
  { name: "神兽·瓦露塔", icon: "◆", x: 80, y: 43, type: "beast" },
  { name: "神兽·瓦鲁达尼亚", icon: "◆", x: 68, y: 22, type: "beast" },
  { name: "神兽·瓦娜波力斯", icon: "◆", x: 31, y: 82, type: "beast" },
  { name: "奥尔龙参考路线", icon: "🐉", x: 72, y: 17, type: "dragon" },
  { name: "聂尔龙参考路线", icon: "🐉", x: 83, y: 62, type: "dragon" },
  { name: "费罗龙参考路线", icon: "🐉", x: 58, y: 88, type: "dragon" },
] as const;

let terrainContextPromise: Promise<CanvasRenderingContext2D> | null = null;

function toTilePoint(point: { x: number; y: number }) {
  return {
    x: tileBounds.left + (point.x / 100) * (tileBounds.right - tileBounds.left),
    y: tileBounds.top + (point.y / 100) * (tileBounds.bottom - tileBounds.top),
  };
}

function fromTilePoint(point: { x: number; y: number }) {
  return {
    x: ((point.x - tileBounds.left) / (tileBounds.right - tileBounds.left)) * 100,
    y: ((point.y - tileBounds.top) / (tileBounds.bottom - tileBounds.top)) * 100,
  };
}

function worldToMapPoint(x: number, z: number) {
  return {
    // 玩家、神庙和塔统一使用游戏世界坐标，不再应用单点视觉补偿。
    x: Math.max(0, Math.min(100, x * worldMapCalibration.xScale + worldMapCalibration.xOffset)),
    y: Math.max(0, Math.min(100, z * worldMapCalibration.zScale + worldMapCalibration.zOffset)),
  };
}

function mapPointToWorld(point: { x: number; y: number }) {
  return {
    x: (point.x - worldMapCalibration.xOffset) / worldMapCalibration.xScale,
    z: (point.y - worldMapCalibration.zOffset) / worldMapCalibration.zScale,
  };
}

async function loadTerrainContext() {
  if (!terrainContextPromise) {
    terrainContextPromise = new Promise<CanvasRenderingContext2D>((resolve, reject) => {
      const image = new Image();
      image.onload = () => {
        const canvas = document.createElement("canvas");
        canvas.width = image.naturalWidth;
        canvas.height = image.naturalHeight;
        const context = canvas.getContext("2d", { willReadFrequently: true });
        if (!context) {
          terrainContextPromise = null;
          reject(new Error("terrain_canvas_unavailable"));
          return;
        }
        context.drawImage(image, 0, 0);
        resolve(context);
      };
      image.onerror = () => {
        terrainContextPromise = null;
        reject(new Error("terrain_heightmap_unavailable"));
      };
      image.src = "/botw-terrain-height.png";
    });
  }
  return terrainContextPromise;
}

async function terrainTeleportHeight(x: number, z: number) {
  const px = x * 0.256 + 1536;
  const pz = z * 0.256 + 1536;
  if (px < 0 || pz < 0 || px >= 3071 || pz >= 3071) throw new Error("terrain_out_of_bounds");
  const context = await loadTerrainContext();
  const sample = context.getImageData(Math.max(0, Math.min(3070, Math.floor(px))), Math.max(0, Math.min(3070, Math.floor(pz))), 2, 2).data;
  const highByte = Math.max(sample[0], sample[4], sample[8], sample[12]);
  // The bundled map keeps the high byte of BOTW's uint16 terrain height.
  // Use the top of that quantisation bucket, then add 3 m of clearance.
  return ((highByte * 256 + 255) * 800) / 65535 + 3;
}

function normalizeDegrees(value: number) {
  return ((value % 360) + 360) % 360;
}

export default function Home() {
  const [filter, setFilter] = useState<string>("全部装备");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Point>(points.find((point) => point.id === 11) || points[0]);
  const [done, setDone] = useState<number[]>([]);
  const [showList, setShowList] = useState(false);
  const [showDetail, setShowDetail] = useState(true);
  const [navigationTarget, setNavigationTarget] = useState<Point | null>(null);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [voiceLanguage, setVoiceLanguage] = useState<VoiceLanguage>("zh-CN");
  const [followPlayer, setFollowPlayer] = useState(true);
  const [trailEnabled, setTrailEnabled] = useState(false);
  const [trail, setTrail] = useState<Array<{ x: number; y: number }>>([]);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const sidebarScrollRef = useRef<HTMLDivElement>(null);
  const lastSpokenRef = useRef("");
  const [switchIp, setSwitchIp] = useState("");
  const [connected, setConnected] = useState(false);
  const [serviceOnline, setServiceOnline] = useState(false);
  const [switchMaxTeleportDistance, setSwitchMaxTeleportDistance] = useState(500);
  const [connectionText, setConnectionText] = useState("等待连接");
  const [devicePos, setDevicePos] = useState<{ x: number; y: number } | null>(null);
  const [worldPos, setWorldPos] = useState<{ x: number; y: number; z: number; yaw: number | null } | null>(null);
  const [initialTowerCalibration, setInitialTowerCalibration] = useState(false);
  const [pickingTeleportPoint, setPickingTeleportPoint] = useState(false);
  const [teleportFeedback, setTeleportFeedback] = useState<TeleportFeedback>({ phase: "idle", message: "" });
  const teleportPollRef = useRef<AbortController | null>(null);
  const teleportPostRef = useRef<AbortController | null>(null);
  const activeTeleportRequestRef = useRef<number | null>(null);

  useEffect(() => {
    let cancelled = false;
    queueMicrotask(() => {
      if (cancelled) return;
      const saved = localStorage.getItem("hyrule-progress");
      if (saved) setDone(JSON.parse(saved));
      const savedVoiceLanguage = localStorage.getItem("hyrule-voice-language");
      if (savedVoiceLanguage === "zh-CN" || savedVoiceLanguage === "ja-JP") {
        setVoiceLanguage(savedVoiceLanguage);
      }
    });
    fetch("/config.json", { cache: "no-store" }).then((response) => response.json()).then((config) => {
      if (cancelled) return;
      const ip = localStorage.getItem("hyrule-switch-ip") || (typeof config.switchIp === "string" ? config.switchIp : "");
      if (ip) { setSwitchIp(ip); setConnected(true); setConnectionText("正在连接"); }
    }).catch(() => undefined);
    return () => { cancelled = true; };
  }, []);

  useEffect(() => () => {
    teleportPostRef.current?.abort();
    teleportPollRef.current?.abort();
    activeTeleportRequestRef.current = null;
  }, []);

  useEffect(() => {
    if (!connected || !switchIp) return;
    const controller = new AbortController();
    let stopped = false;
    let timer: number | undefined;
    const poll = async () => {
      try {
        const statusPromise = fetch(`http://${switchIp}:37890/v1/teleport/status`, {
          signal: controller.signal,
          cache: "no-store",
        }).then((response) => response.json()).catch(() => null);
        const response = await fetch(`http://${switchIp}:37890/v1/position`, { signal: controller.signal, cache: "no-store" });
        const data = await response.json();
        const status = await statusPromise;
        if (status && Number.isFinite(Number(status.maxDistance)) && Number(status.maxDistance) > 0) {
          setSwitchMaxTeleportDistance(Number(status.maxDistance));
        }
        setServiceOnline(true);
        if (data.ok && typeof data.x === "number" && typeof data.y === "number" && typeof data.z === "number") {
          setConnectionText("坐标同步中");
          setWorldPos({ x: data.x, y: data.y, z: data.z, yaw: typeof data.yaw === "number" ? data.yaw : null });
          const point = worldToMapPoint(data.x, data.z);
          setDevicePos(point);
          if (trailEnabled) setTrail((current) => {
            const last = current[current.length - 1];
            if (last && Math.hypot(last.x - point.x, last.y - point.y) < 0.08) return current;
            return [...current, point].slice(-100);
          });
        } else {
          setDevicePos(null); setWorldPos(null);
          const messages: Record<string, string> = { game_not_running: "请启动旷野之息并进入存档", wrong_game: "未识别到游戏", wrong_build_id: "游戏版本不匹配", position_not_found: "坐标暂不可用", attach_retry: "正在安全连接游戏", attach_failed: "暂时无法连接游戏", metadata_failed: "读取游戏失败" };
          setConnectionText(messages[data.error] || "等待游戏坐标");
        }
      } catch { setServiceOnline(false); setConnectionText("主机未连接"); setDevicePos(null); setWorldPos(null); }
    };
    const pollSerially = async () => { await poll(); if (!stopped) timer = window.setTimeout(pollSerially, 1000); };
    pollSerially();
    return () => { stopped = true; if (timer) window.clearTimeout(timer); controller.abort(); setServiceOnline(false); };
  }, [connected, switchIp, trailEnabled]);

  const visible = useMemo(() => allPoints.filter((point) => {
    const matchesKind = filter === "全部" || (filter === "全部装备" ? equipmentKinds.includes(point.kind) : point.kind === filter);
    return matchesKind && `${point.name}${point.region}${point.kind}`.toLowerCase().includes(query.toLowerCase());
  }), [filter, query]);

  const selectedTeleportCoordinates = useMemo<TeleportCoordinates | null>(() => {
    return landmarkTeleportTargets.get(selected.id) || null;
  }, [selected.id]);
  const selectedTeleportDistance = useMemo(() => {
    if (!worldPos || !selectedTeleportCoordinates) return null;
    return Math.hypot(selectedTeleportCoordinates.x - worldPos.x, selectedTeleportCoordinates.z - worldPos.z);
  }, [selectedTeleportCoordinates, worldPos]);
  const teleportBusy = ["sending", "pending", "confirmed", "executing"].includes(teleportFeedback.phase);
  const teleportDisabledReason = !connected || !serviceOnline
    ? "请先连接 Switch"
    : !worldPos
      ? "请进入游戏存档，等待坐标正常"
      : !selectedTeleportCoordinates
        ? "该标记不是已验证传送点；只能导航，不能传送"
        : selectedTeleportDistance != null && selectedTeleportDistance > switchMaxTeleportDistance
          ? `目标距离 ${Math.round(selectedTeleportDistance)} 米，Switch 当前限制为 ${switchMaxTeleportDistance} 米`
          : teleportBusy
            ? "Switch 正在处理一个传送目标"
            : "";
  const teleportFeedbackIsSelected = teleportFeedback.pointId === selected.id;
  const teleportButtonText = teleportFeedbackIsSelected && teleportFeedback.phase === "sending"
    ? "正在发送…"
    : teleportFeedbackIsSelected && ["pending", "confirmed"].includes(teleportFeedback.phase)
      ? "已保存到 Switch"
      : teleportFeedbackIsSelected && teleportFeedback.phase === "executing"
        ? "正在传送…"
        : teleportFeedbackIsSelected && teleportFeedback.phase === "succeeded"
          ? "✓ 传送完成"
          : "⇄ 发送到 Switch";

  const displayedDevicePos = initialTowerCalibration ? initialTowerSample.map : devicePos;
  const renderedDevicePos = useMemo(() => displayedDevicePos ? toTilePoint(displayedDevicePos) : null, [displayedDevicePos]);

  const navigation = useMemo(() => {
    if (!navigationTarget || !worldPos) return null;
    const targetWorld = mapPointToWorld(navigationTarget);
    const dx = targetWorld.x - worldPos.x;
    const dz = targetWorld.z - worldPos.z;
    const distance = Math.hypot(dx, dz);
    const bearing = normalizeDegrees(Math.atan2(dx, -dz) * 180 / Math.PI);
    const directions = ["北", "东北", "东", "东南", "南", "西南", "西", "西北"];
    return {
      distance,
      bearing,
      direction: directions[Math.round(bearing / 45) % 8],
      turn: worldPos.yaw == null ? null : normalizeDegrees(bearing - worldPos.yaw + 180) - 180,
      arrived: distance < 20,
    };
  }, [navigationTarget, worldPos]);

  const navigationPrompt = useMemo(() => {
    if (!navigation) return "等待主机实时坐标";
    if (navigation.arrived) return `已到达${navigationTarget?.name || "目标"}附近`;
    const distanceStep = navigation.distance < 100 ? 5 : navigation.distance < 500 ? 10 : navigation.distance < 2000 ? 25 : 50;
    const distance = Math.max(5, Math.round(navigation.distance / distanceStep) * distanceStep);
    if (navigation.turn == null) return `前方约 ${distance} 米，向${navigation.direction}方向前进`;
    const turn = navigation.turn;
    const angle = Math.abs(turn);
    const maneuver = angle < 10 ? "继续直行" : angle < 35 ? `稍向${turn > 0 ? "右" : "左"}` : angle < 120 ? `向${turn > 0 ? "右" : "左"}转` : "掉头";
    return `前方约 ${distance} 米，${maneuver}`;
  }, [navigation, navigationTarget]);

  const voicePrompt = useMemo(() => {
    if (voiceLanguage === "zh-CN" || !navigation) return navigationPrompt;
    if (navigation.arrived) return `目的地、${navigationTarget?.name || "目標"}付近に到着しました`;
    const distanceStep = navigation.distance < 100 ? 5 : navigation.distance < 500 ? 10 : navigation.distance < 2000 ? 25 : 50;
    const distance = Math.max(5, Math.round(navigation.distance / distanceStep) * distanceStep);
    const directionJapanese: Record<string, string> = { 北: "北", 东北: "北東", 东: "東", 东南: "南東", 南: "南", 西南: "南西", 西: "西", 西北: "北西" };
    if (navigation.turn == null) return `およそ${distance}メートル先、${directionJapanese[navigation.direction]}の方向へ進んでください`;
    const angle = Math.abs(navigation.turn);
    const maneuver = angle < 10 ? "そのまま直進してください" : angle < 35 ? `少し${navigation.turn > 0 ? "右" : "左"}へ進んでください` : angle < 120 ? `${navigation.turn > 0 ? "右" : "左"}へ曲がってください` : "ユーターンしてください";
    return `およそ${distance}メートル先、${maneuver}`;
  }, [navigation, navigationPrompt, navigationTarget, voiceLanguage]);

  const renderedNavigation = useMemo(() => {
    if (!navigationTarget || !devicePos) return null;
    const from = toTilePoint(devicePos);
    const to = toTilePoint(navigationTarget);
    const dx = to.x - from.x;
    const dy = to.y - from.y;
    return {
      from,
      lineLength: Math.hypot(dx, dy),
      lineAngle: Math.atan2(dy, dx) * 180 / Math.PI,
    };
  }, [navigationTarget, devicePos]);

  useEffect(() => {
    if (!voiceEnabled || !navigationTarget || !navigation || typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const speechKey = `${voiceLanguage}:${navigationTarget.id}:${voicePrompt}`;
    if (lastSpokenRef.current === speechKey) return;
    lastSpokenRef.current = speechKey;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(voicePrompt);
    utterance.lang = voiceLanguage;
    const preferredVoice = window.speechSynthesis.getVoices().find((voice) => voice.lang.toLowerCase().startsWith(voiceLanguage.slice(0, 2).toLowerCase()));
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.rate = .92;
    utterance.pitch = 1;
    window.speechSynthesis.speak(utterance);
  }, [voiceEnabled, voiceLanguage, navigationTarget, navigation, voicePrompt]);

  const facing = useMemo(() => {
    if (worldPos?.yaw == null) return "等待方向";
    const directions = ["北", "东北", "东", "东南", "南", "西南", "西", "西北"];
    const yaw = normalizeDegrees(worldPos.yaw);
    return `${directions[Math.round(yaw / 45) % 8]} · ${Math.round(yaw)}°`;
  }, [worldPos]);

  function teleportErrorText(error: string) {
    const messages: Record<string, string> = {
      teleport_busy: "Switch 还有一个待确认目标，请先确认或取消",
      target_too_far: "该目标被 Switch 安全策略拒绝，请改选已验证的附近传送点",
      height_delta_too_large: "目标高度变化过大，请改选附近地表",
      game_not_running: "请启动旷野之息并进入存档",
      wrong_game: "当前运行的不是旷野之息",
      wrong_build_id: "仅支持旷野之息 1.6.0 指定 Build ID",
      position_not_found: "林克当前不可控，请结束读档、过场或菜单",
      unsafe_game_state: "林克当前状态不安全，请回到可操作地面",
      game_changed: "游戏进程已变化，传送已停止",
      service_stopping: "Switch 服务正在停止，传送已取消",
      memory_write_failed: "坐标写入失败，未继续执行",
      partial_memory_write: "坐标只完成了部分写入；为防止继续损坏状态，本次游戏已锁定传送",
      abnormal_landing: "检测到异常落点；本次游戏已锁定传送，请重启游戏",
      landing_not_stable: "落地状态持续不稳定；本次游戏已锁定传送，请重启游戏",
      position_unreadable_after_write: "写入后无法继续读取林克；请重启游戏，不要再次传送",
      movement_not_confirmed_restart_game: "传送后未确认林克可移动；本次游戏已锁定传送，请重启游戏",
      postflight_unreadable_restart_game: "传送后连续读取复核失败；本次游戏已锁定传送，请重启游戏",
      direct_warp_quarantined: "检测到上次直接写坐标异常；必须重启游戏后才能再次传送",
      confirmation_timeout: "Switch 端 30 秒内未确认，目标已过期",
      cancelled_on_switch: "已在 Switch 端取消",
    };
    return messages[error] || `传送失败：${error || "未知错误"}`;
  }

  async function pollTeleportStatus(requestId: number, pointId: number) {
    teleportPollRef.current?.abort();
    const controller = new AbortController();
    teleportPollRef.current = controller;
    for (let attempt = 0; attempt < 55 && !controller.signal.aborted; attempt += 1) {
      await new Promise<void>((resolve) => window.setTimeout(resolve, 700));
      if (controller.signal.aborted || activeTeleportRequestRef.current !== requestId) return;
      try {
        const response = await fetch(`http://${switchIp}:37890/v1/teleport/status`, { signal: controller.signal, cache: "no-store" });
        const data = await response.json();
        if (Number.isFinite(Number(data.maxDistance)) && Number(data.maxDistance) > 0) {
          setSwitchMaxTeleportDistance(Number(data.maxDistance));
        }
        if (controller.signal.aborted || activeTeleportRequestRef.current !== requestId) return;
        if (Number(data.requestId) !== requestId) continue;
        const phase = String(data.state) as TeleportPhase;
        if (phase === "pending") setTeleportFeedback({ phase, requestId, pointId, message: "已发送到 Switch，请在特斯拉菜单“实验传送”中选择“确认传送”并按 A" });
        else if (phase === "confirmed") setTeleportFeedback({ phase, requestId, pointId, message: "Switch 已确认，正在等待安全执行" });
        else if (phase === "executing") setTeleportFeedback({ phase, requestId, pointId, message: "正在写入并复核林克位置，请不要关游戏" });
        else if (phase === "succeeded") {
          setTeleportFeedback({ phase, requestId, pointId, message: "传送成功，正在同步新位置" });
          activeTeleportRequestRef.current = null;
          return;
        } else if (phase === "failed" || phase === "cancelled" || phase === "expired") {
          setTeleportFeedback({ phase, requestId, pointId, message: teleportErrorText(String(data.error || phase)) });
          activeTeleportRequestRef.current = null;
          return;
        }
      } catch {
        if (!controller.signal.aborted) setTeleportFeedback((current) => ({ ...current, message: "传送目标仍保留在 Switch，状态连接暂时中断" }));
      }
    }
    if (!controller.signal.aborted && activeTeleportRequestRef.current === requestId) {
      activeTeleportRequestRef.current = null;
      setTeleportFeedback({ phase: "expired", requestId, pointId, message: "等待状态超时，请先在 Switch 菜单确认当前结果" });
    }
  }

  async function sendTeleport() {
    if (teleportDisabledReason || !selectedTeleportCoordinates) return;
    const requestId = Date.now();
    teleportPostRef.current?.abort();
    const controller = new AbortController();
    teleportPostRef.current = controller;
    activeTeleportRequestRef.current = requestId;
    const timeout = window.setTimeout(() => controller.abort(), 5000);
    setTeleportFeedback({ phase: "sending", requestId, pointId: selected.id, message: "正在把已验证目标发送到 Switch" });
    const body = new URLSearchParams({
      v: "2",
      requestId: String(requestId),
      id: String(selected.id),
      x: selectedTeleportCoordinates.x.toFixed(3),
      y: selectedTeleportCoordinates.y.toFixed(3),
      z: selectedTeleportCoordinates.z.toFixed(3),
      source: selectedTeleportCoordinates.source,
    }).toString();
    try {
      const response = await fetch(`http://${switchIp}:37890/v1/waypoint`, {
        method: "POST",
        headers: { "Content-Type": "text/plain" },
        body,
        signal: controller.signal,
      });
      const data = await response.json();
      if (controller.signal.aborted || activeTeleportRequestRef.current !== requestId) return;
      if (!response.ok || !data.ok) {
        if (Number.isFinite(Number(data.maxDistance)) && Number(data.maxDistance) > 0) {
          setSwitchMaxTeleportDistance(Number(data.maxDistance));
        }
        activeTeleportRequestRef.current = null;
        setTeleportFeedback({ phase: "failed", requestId, pointId: selected.id, message: teleportErrorText(String(data.error || `HTTP ${response.status}`)) });
        return;
      }
      setTeleportFeedback({ phase: "pending", requestId, pointId: selected.id, message: "路标已保存到 Switch；打开特斯拉插件，选择“传送到电脑路标”并按 A" });
      pollTeleportStatus(requestId, selected.id).catch(() => undefined);
    } catch {
      if (activeTeleportRequestRef.current !== requestId) return;
      activeTeleportRequestRef.current = null;
      setTeleportFeedback({ phase: "failed", requestId, pointId: selected.id, message: controller.signal.aborted ? "发送超时；不会自动重试，请检查 Switch 服务" : "无法发送目标；不会自动重试，请检查 Switch 服务" });
    } finally {
      window.clearTimeout(timeout);
      if (teleportPostRef.current === controller) teleportPostRef.current = null;
    }
  }

  function cancelTeleportNetworking() {
    activeTeleportRequestRef.current = null;
    teleportPostRef.current?.abort();
    teleportPollRef.current?.abort();
    teleportPostRef.current = null;
    teleportPollRef.current = null;
    setTeleportFeedback({ phase: "idle", message: "" });
  }

  async function selectTerrainTeleportPoint(event: ReactMouseEvent<HTMLDivElement>) {
    if (!pickingTeleportPoint || teleportBusy) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const mapPoint = fromTilePoint({
      x: ((event.clientX - rect.left) / rect.width) * 100,
      y: ((event.clientY - rect.top) / rect.height) * 100,
    });
    if (mapPoint.x < 0 || mapPoint.x > 100 || mapPoint.y < 0 || mapPoint.y > 100) {
      setTeleportFeedback({ phase: "failed", message: "请选择海拉鲁主地图范围内的地表" });
      return;
    }
    const world = mapPointToWorld(mapPoint);
    setTeleportFeedback({ phase: "sending", message: "正在计算该点的安全目标高度" });
    try {
      const height = await terrainTeleportHeight(world.x, world.z);
      const point: Point = {
        id: -1,
        name: "自选地表传送点",
        region: "电脑端选点",
        kind: "地点",
        x: mapPoint.x,
        y: mapPoint.y,
        note: "地形安全目标点；请勿选择水面、桥梁、建筑、洞穴或悬空结构。",
        teleport: { x: world.x, y: height, z: world.z, source: "terrain" },
      };
      setSelected(point);
      setPickingTeleportPoint(false);
      setShowDetail(true);
      setShowList(false);
      setTeleportFeedback({ phase: "idle", message: `已计算安全目标高度 ${height.toFixed(1)} 米，请确认目标` });
    } catch {
      setTeleportFeedback({ phase: "failed", message: "这个位置没有可用的地表高度，请改选地图内陆地" });
    }
  }

  function choose(point: Point) { setPickingTeleportPoint(false); setSelected(point); setShowDetail(true); setShowList(false); }
  function setProgress(id: number) {
    const next = done.includes(id) ? done.filter((item) => item !== id) : [...done, id];
    setDone(next); localStorage.setItem("hyrule-progress", JSON.stringify(next));
  }
  function zoomBy(delta: number) { setZoom((value) => Math.max(1, Math.min(8, Number((value + delta).toFixed(2))))); }
  function scrollSidebarBy(top: number) { sidebarScrollRef.current?.scrollBy({ top, behavior: "smooth" }); }
  function scrollSidebarTo(edge: "start" | "end") {
    const panel = sidebarScrollRef.current;
    if (!panel) return;
    panel.scrollTo({ top: edge === "start" ? 0 : panel.scrollHeight, behavior: "smooth" });
  }
  function locatePlayer() { setFollowPlayer(true); if (displayedDevicePos) { setZoom(2.25); setPan({ x: 0, y: 0 }); } }
  function toggleInitialTowerCalibration() {
    const next = !initialTowerCalibration;
    setInitialTowerCalibration(next);
    if (next) {
      setFilter("塔");
      setSelected(points[0]);
      setShowDetail(false);
      setShowList(false);
      setFollowPlayer(true);
      setZoom(2.25);
      setPan({ x: 0, y: 0 });
    }
  }
  function startNavigation(point: Point) {
    lastSpokenRef.current = "";
    setNavigationTarget(point);
    setShowDetail(false);
    setShowList(false);
    setFollowPlayer(true);
    setTrailEnabled(true);
    if (devicePos) setZoom(Math.max(1.25, Math.min(2.25, 80 / Math.max(35, Math.hypot(point.x - devicePos.x, point.y - devicePos.y)))));
  }
  function selectNearest() {
    if (!devicePos) return;
    choose(allPoints.reduce((best, point) => Math.hypot(point.x - devicePos.x, point.y - devicePos.y) < Math.hypot(best.x - devicePos.x, best.y - devicePos.y) ? point : best));
  }
  function toggleVoiceLanguage() {
    const next: VoiceLanguage = voiceLanguage === "zh-CN" ? "ja-JP" : "zh-CN";
    window.speechSynthesis?.cancel();
    lastSpokenRef.current = "";
    setVoiceLanguage(next);
    localStorage.setItem("hyrule-voice-language", next);
  }

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.matches("input, textarea, select, [contenteditable='true']")) return;
      const sidebarVisible = window.innerWidth > 800 || showList;
      if (sidebarVisible && event.key === "ArrowDown") { event.preventDefault(); scrollSidebarBy(64); return; }
      if (sidebarVisible && event.key === "ArrowUp") { event.preventDefault(); scrollSidebarBy(-64); return; }
      if (sidebarVisible && event.key === "PageDown") { event.preventDefault(); scrollSidebarBy(260); return; }
      if (sidebarVisible && event.key === "PageUp") { event.preventDefault(); scrollSidebarBy(-260); return; }
      if (sidebarVisible && event.key === "Home") { event.preventDefault(); scrollSidebarTo("start"); return; }
      if (sidebarVisible && event.key === "End") { event.preventDefault(); scrollSidebarTo("end"); return; }
      if (event.key === "+" || event.key === "=") zoomBy(.35);
      if (event.key === "-") zoomBy(-.35);
      if (event.key.toLowerCase() === "y") setShowList((value) => !value);
      if (event.key.toLowerCase() === "x") setTrailEnabled((value) => !value);
      if (event.key.toLowerCase() === "a") selectNearest();
      if (event.key.toLowerCase() === "b") { setShowDetail(false); setShowList(false); }
      if (event.key.toLowerCase() === "l") locatePlayer();
      if (event.key.toLowerCase() === "t") toggleInitialTowerCalibration();
    };
    window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key);
  });

  return (
    <main className="shell">
      <header className="topbar">
        <div className="brand"><span className="eye">◉</span><div><strong>海拉鲁全图导航</strong><small>希卡石板 · 旷野之息 1.6.0</small></div></div>
        <div className="switch-link"><i className={serviceOnline ? "online" : ""} /><div className="switch-fields"><input aria-label="主机地址" placeholder="主机地址" value={switchIp} onChange={(e) => { const ip = e.target.value.replace(/[^0-9.]/g, ""); cancelTeleportNetworking(); setSwitchIp(ip); localStorage.setItem("hyrule-switch-ip", ip); }} /><small>{connectionText}{worldPos ? ` · 东西 ${worldPos.x.toFixed(0)} 南北 ${worldPos.z.toFixed(0)}` : ""}</small></div><button disabled={!switchIp} onClick={() => { if (connected) cancelTeleportNetworking(); setConnected((value) => !value); setConnectionText(connected ? "已断开" : "正在连接"); }}>{connected ? "断开" : "连接"}</button></div>
      </header>

      <section className="workspace">
        <aside className={`sidebar ${showList ? "open" : ""}`}>
          <div className="panel-title"><span>筛选标记</span><button onClick={() => setShowList(false)}>×</button></div>
          <label className="search"><span>⌕</span><input aria-label="搜索地图" placeholder="搜索装备、地点或地区" value={query} onChange={(e) => setQuery(e.target.value)} /></label>
          <div id="sidebar-scroll" className="sidebar-scroll" ref={sidebarScrollRef} tabIndex={0} aria-label="筛选与地图标记列表">
            <button className={`filter-wide ${filter === "全部" ? "active" : ""}`} onClick={() => setFilter("全部")}><span>◉</span> 显示全部 <b>{allPoints.length}</b></button>
            <section className="filter-group"><h2>装备地图</h2><button className={filter === "全部装备" ? "active" : ""} onClick={() => setFilter("全部装备")}><span>✥</span>全部装备<b>{allPoints.filter((p) => equipmentKinds.includes(p.kind)).length}</b></button>{equipmentKinds.map((kind) => <button key={kind} className={filter === kind ? "active" : ""} onClick={() => setFilter(kind)}><span>{icons[kind]}</span>{kind}<b>{allPoints.filter((p) => p.kind === kind).length}</b></button>)}</section>
            <section className="filter-group"><h2>地点与传送</h2>{locationKinds.map((kind) => <button key={kind} className={filter === kind ? "active" : ""} onClick={() => setFilter(kind)}><span>{icons[kind]}</span>{kind}<b>{allPoints.filter((p) => p.kind === kind).length}</b></button>)}</section>
            <section className="filter-group"><h2>探索与敌人</h2>{explorationKinds.map((kind) => <button key={kind} className={filter === kind ? "active" : ""} onClick={() => setFilter(kind)}><span>{icons[kind]}</span>{kind}<b>{allPoints.filter((p) => p.kind === kind).length}</b></button>)}</section>
            <section className="filter-group"><h2>资源</h2>{resourceKinds.map((kind) => <button key={kind} className={filter === kind ? "active" : ""} onClick={() => setFilter(kind)}><span>{icons[kind]}</span>{kind}<b>{allPoints.filter((p) => p.kind === kind).length}</b></button>)}</section>
            <div className="result-title"><span>地图标记</span><b>{visible.length}</b></div>
            <div className="place-list">{visible.map((point) => <button key={point.id} className={`place-row ${selected.id === point.id ? "selected" : ""}`} onClick={() => choose(point)}><span className={`kind kind-${point.kind}`}>{icons[point.kind]}</span><span><strong>{point.name}</strong><small>{point.region} · {point.kind}</small></span>{done.includes(point.id) && <em>✓</em>}</button>)}</div>
          </div>
          <div className="list-scroll-controls" aria-label="列表滚动控制">
            <button type="button" aria-controls="sidebar-scroll" aria-label="向上滚动筛选列表" onClick={() => scrollSidebarBy(-240)}>▲ <span>上移</span></button>
            <small><kbd>↑</kbd><kbd>↓</kbd><span>方向键滚动</span></small>
            <button type="button" aria-controls="sidebar-scroll" aria-label="向下滚动筛选列表" onClick={() => scrollSidebarBy(240)}><span>下移</span> ▼</button>
          </div>
        </aside>

        <div className="map-wrap">
          <div className="map-toolbar"><button className="mobile-list" onClick={() => setShowList((value) => !value)}>☰ 筛选</button><span className="layer-pill">◈ {pickingTeleportPoint ? "点击陆地选择传送点" : navigationTarget ? `导航：${navigationTarget.name}` : "海拉鲁完整地表"} <b>{pickingTeleportPoint ? "选点中" : navigationTarget ? "进行中" : filter}</b></span><button className="surface-pick" disabled aria-label="仅支持已验证传送点">✓ 固定安全点</button><button className={`locate ${followPlayer ? "active" : ""}`} onClick={locatePlayer} aria-label="定位林克">⌖</button></div>
          {(pickingTeleportPoint || teleportFeedback.message) && <div className={`teleport-banner phase-${teleportFeedback.phase} ${pickingTeleportPoint ? "picking" : ""}`}><strong>{pickingTeleportPoint ? "传送选点模式" : "Switch 传送"}</strong><span>{pickingTeleportPoint ? "请点陆地表面；不要选水面、桥梁、建筑、洞穴或悬空结构" : teleportFeedback.message}</span>{!pickingTeleportPoint && ["failed", "cancelled", "expired", "succeeded"].includes(teleportFeedback.phase) && <button onClick={() => setTeleportFeedback({ phase: "idle", message: "" })}>关闭</button>}</div>}
          <div className="zoom-control"><button onClick={() => zoomBy(.35)} aria-label="放大">＋</button><button onClick={() => zoomBy(-.35)} aria-label="缩小">－</button><small>{Math.round(zoom * 100)}%</small></div>
          <div className={`map-viewport ${pickingTeleportPoint ? "picking" : ""}`} onWheel={(event) => { event.preventDefault(); zoomBy(event.deltaY < 0 ? .2 : -.2); }} onPointerDown={(event) => { if (pickingTeleportPoint) return; drag.current = { x: event.clientX, y: event.clientY, px: pan.x, py: pan.y }; event.currentTarget.setPointerCapture(event.pointerId); }} onPointerMove={(event) => { if (!drag.current) return; setFollowPlayer(false); setPan({ x: drag.current.px + event.clientX - drag.current.x, y: drag.current.py + event.clientY - drag.current.y }); }} onPointerUp={() => { drag.current = null; }}>
            <div className="map-canvas" style={{ transform: `translate(${pan.x}px, ${pan.y}px)` }}>
              <div className="map-world-frame">
                <div className={`map-world ${pickingTeleportPoint ? "picking" : ""}`} onClick={selectTerrainTeleportPoint} style={{ transform: `scale(${zoom})`, transformOrigin: renderedDevicePos && followPlayer ? `${renderedDevicePos.x}% ${renderedDevicePos.y}%` : "50% 50%", "--map-scale": zoom } as CSSProperties}>
                  <div className="tile-grid">{Array.from({ length: 16 }, (_, y) => y).flatMap((y) => Array.from({ length: 16 }, (_, x) => <img key={`${x}-${y}`} src={`/hyrule-tiles-hd/4_${x}_${y}.png`} alt="" draggable={false} />))}</div>
                  <div className="map-shade" />
                  <div className="region-label-layer" aria-hidden="true">{regionLabels.map(([name, x, y]) => { const p = toTilePoint({ x, y }); return <span key={name} style={{ left: `${p.x}%`, top: `${p.y}%` }}>{name}</span>; })}</div>
                  <div className="legendary-layer">{legendaryMarkers.map((marker) => { const p = toTilePoint(marker); return <button key={marker.name} className={`legendary-marker ${marker.type}`} style={{ left: `${p.x}%`, top: `${p.y}%` }} title={marker.name} onClick={(event) => event.stopPropagation()}><span>{marker.icon}</span><b>{marker.name}</b></button>; })}</div>
                  {renderedNavigation && <div className="nav-line" style={{ left: `${renderedNavigation.from.x}%`, top: `${renderedNavigation.from.y}%`, width: `${renderedNavigation.lineLength}%`, transform: `rotate(${renderedNavigation.lineAngle}deg)` }}><i /></div>}
                  {visible.map((point) => { const mapPoint = toTilePoint(point); return <button key={point.id} className={`marker kind-marker-${point.kind} ${visible.length > 300 ? "dense" : ""} ${selected.id === point.id ? "current" : ""} ${navigationTarget?.id === point.id ? "nav-target" : ""} ${done.includes(point.id) ? "done" : ""}`} style={{ left: `${mapPoint.x}%`, top: `${mapPoint.y}%` }} title={point.name} aria-label={point.name} onPointerDown={(e) => e.stopPropagation()} onClick={(event) => { event.stopPropagation(); choose(point); }}><span>{icons[point.kind]}</span></button>; })}
                  {selected.teleport?.source === "terrain" && <button className="custom-teleport-marker" style={{ left: `${toTilePoint(selected).x}%`, top: `${toTilePoint(selected).y}%` }} title="自选地表传送点" onClick={(event) => event.stopPropagation()}>⇄</button>}
                  {trailEnabled && trail.map((point, index) => { const mapPoint = toTilePoint(point); return <i className="trail-point" key={`${index}-${point.x.toFixed(2)}`} style={{ left: `${mapPoint.x}%`, top: `${mapPoint.y}%`, opacity: .2 + index / Math.max(1, trail.length) * .75 }} />; })}
                  {renderedDevicePos && <div className="player" style={{ left: `${renderedDevicePos.x}%`, top: `${renderedDevicePos.y}%`, "--heading": `${(initialTowerCalibration ? initialTowerSample.world.yaw : (worldPos?.yaw ?? 0)) - 90}deg` } as CSSProperties}><span>➤</span><b>{initialTowerCalibration ? "校准点 · 初始之塔" : `林克 · ${facing}`}</b></div>}
                </div>
              </div>
            </div>
          </div>

          {navigationTarget && <section className={`nav-panel ${navigation?.arrived ? "arrived" : ""}`}>
            <span className="nav-arrow">➤</span>
            <div><small>{navigation?.arrived ? "已到达目标附近" : "实时转向提示"}</small><strong>{navigationTarget.name}</strong><p className="nav-instruction">{navigationPrompt}</p>{navigation && <em>{navigation.direction}方向 · 约 {Math.round(navigation.distance)} 米</em>}</div>
            <div className="nav-actions"><button className={voiceEnabled ? "voice-on" : ""} onClick={() => { window.speechSynthesis?.cancel(); lastSpokenRef.current = ""; setVoiceEnabled((value) => !value); }} aria-label={voiceEnabled ? "关闭语音提示" : "开启语音提示"}>{voiceEnabled ? "🔊 语音开启" : "🔇 语音关闭"}</button><button className="voice-on" onClick={toggleVoiceLanguage} aria-label="切换播报语言">播报：{voiceLanguage === "zh-CN" ? "中文" : "日语"}</button><button onClick={() => { window.speechSynthesis?.cancel(); setNavigationTarget(null); }}>停止导航</button></div>
          </section>}

          <div className="slate-status"><strong>{initialTowerCalibration ? "初始之塔坐标校准" : worldPos ? "位置与角色方向同步" : "等待希卡感应"}</strong><small>{initialTowerCalibration ? `东西 ${initialTowerSample.world.x.toFixed(1)} · 高度 ${initialTowerSample.world.y.toFixed(1)} · 南北 ${initialTowerSample.world.z.toFixed(1)}` : worldPos ? `东西 ${worldPos.x.toFixed(1)} · 高度 ${worldPos.y.toFixed(1)} · 南北 ${worldPos.z.toFixed(1)}` : connectionText}</small><em>{initialTowerCalibration ? "● 模拟位置" : serviceOnline ? `● ${facing}` : "○ 未连接"}</em></div>
          <div className="slate-controls"><button onClick={locatePlayer}>定位 <kbd>L</kbd></button><button onClick={() => setShowList((value) => !value)}>筛选 <kbd>Y</kbd></button><button className={trailEnabled ? "active" : ""} onClick={() => { setTrailEnabled((value) => !value); if (trailEnabled) setTrail([]); }}>足迹 <kbd>X</kbd></button><button onClick={() => { setShowDetail(false); setShowList(false); }}>返回 <kbd>B</kbd></button><button disabled={!devicePos} onClick={selectNearest}>最近装备 <kbd>A</kbd></button><button onClick={() => zoomBy(.35)}>缩放 <kbd>R</kbd></button><button className={initialTowerCalibration ? "active" : ""} onClick={toggleInitialTowerCalibration}>{initialTowerCalibration ? "退出模拟" : "初始塔模拟"} <kbd>T</kbd></button></div>

          {showDetail && <article className="detail-card">
            <button className="close" onClick={() => setShowDetail(false)} aria-label="关闭详情">×</button>
            <div className="detail-head"><span className={`kind kind-${selected.kind}`}>{icons[selected.kind]}</span><div><small>{selected.kind} · {selected.region}</small><h1>{selected.name}</h1></div></div>
            <p>{selected.note}</p>
            <div className="coords"><span>{selectedTeleportCoordinates ? "已验证传送坐标" : "全图位置"}</span><b>{selectedTeleportCoordinates ? `${selectedTeleportCoordinates.x.toFixed(0)} / ${selectedTeleportCoordinates.y.toFixed(0)} / ${selectedTeleportCoordinates.z.toFixed(0)}` : `横向 ${selected.x.toFixed(1)}%　纵向 ${selected.y.toFixed(1)}%`}</b></div>
            <div className="actions">
              <button onClick={sendTeleport} disabled={Boolean(teleportDisabledReason)} title={teleportDisabledReason || "发送后必须在 Switch 特斯拉菜单按 A 确认"} className={`teleport ${teleportFeedbackIsSelected ? `phase-${teleportFeedback.phase}` : ""}`}>{teleportButtonText}</button>
              {!selectedTeleportCoordinates && <button disabled className="surface-route">仅可导航</button>}
              <button onClick={() => startNavigation(selected)} className={`navigate ${navigationTarget?.id === selected.id ? "active" : ""}`}>{navigationTarget?.id === selected.id ? "➤ 正在导航" : "➤ 导航到这里"}</button>
              <button onClick={() => { setZoom(2.4); setPan({ x: 0, y: 0 }); }} className="route">⌖ 地图聚焦</button>
              <button className={`complete ${done.includes(selected.id) ? "active" : ""}`} onClick={() => setProgress(selected.id)}>{done.includes(selected.id) ? "✓ 已收集" : "标记已收集"}</button>
            </div>
            {teleportDisabledReason && <small className="teleport-reason">{teleportDisabledReason}</small>}
          </article>}
        </div>
      </section>
    </main>
  );
}
