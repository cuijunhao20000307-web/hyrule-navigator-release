import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "海拉鲁导航｜旷野之息独立伴侣",
  description: "为《塞尔达传说：旷野之息》玩家制作的非官方本地地图、探索进度与路线规划工具。",
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN"><body>{children}</body></html>;
}
