@echo off
chcp 65001 >nul
set "PROGRAM_DIR=%~dp0..\程序文件"
if not exist "%PROGRAM_DIR%\package.json" (
  echo [错误] 找不到“程序文件”目录，请重新解压整个压缩包。
  pause
  exit /b 1
)
where node >nul 2>nul || (echo [错误] 请安装 Node.js 22 或更高版本。& pause & exit /b 1)
where npm >nul 2>nul || (echo [错误] 未找到 npm，请重新安装 Node.js 22。& pause & exit /b 1)
cd /d "%PROGRAM_DIR%"
if not exist node_modules (
  echo 首次启动，正在安装运行依赖……
  call npm ci || (echo [错误] 依赖安装失败。& pause & exit /b 1)
)
start "" /b cmd /c "timeout /t 4 /nobreak >nul & start http://localhost:3000"
echo 海拉鲁导航正在启动：http://localhost:3000
call npm run dev -- --hostname 0.0.0.0
