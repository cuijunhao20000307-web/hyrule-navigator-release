import { readFile, writeFile } from "node:fs/promises";
import { translateMarkerName } from "./marker-name-zh.mjs";

const input = process.argv[2];
const output = process.argv[3];

if (!input || !output) {
  throw new Error("用法：node scripts/import-reference-markers.mjs <marker.js> <output.json>");
}

const source = await readFile(input, "utf8");
const json = source
  .replace(/^\uFEFF?var markerData\s*=\s*/, "")
  .replace(/;\s*$/, "");
const markers = JSON.parse(json);

const kindByCategory = {
  1901: "地点",
  1903: "武器",
  1904: "弓箭",
  1905: "盾牌",
  1906: "盔甲",
  1910: "材料",
  1911: "食材",
  1912: "食材",
  1913: "食材",
  1914: "食材",
  1915: "材料",
  1916: "呀哈哈",
  1920: "地点",
  1921: "村落",
  1922: "村落",
  1923: "塔",
  1924: "地点",
  1925: "神庙",
  1926: "神兽",
  1927: "地点",
  1930: "敌人营地",
  1931: "敌人营地",
  1932: "守护者",
  1933: "首领",
  1934: "记忆",
  1935: "任务",
  1936: "可破坏墙",
  1937: "大精灵",
  1938: "马宿",
};

const featuredNames = new Set([
  "Great Plateau Tower",
  "Oman Au Shrine",
  "Wahgo Katta Shrine",
  "Kakariko Village",
  "Hateno Village",
  "Dueling Peaks Tower",
  "Ridgeland Tower",
  "Lanayru Tower",
]);

const bounds = { left: 34.25, right: 221, top: 49.875, bottom: 206 };
const round = (value) => Math.round(value * 1_000_000) / 1_000_000;

const points = markers
  .filter((marker) => kindByCategory[marker.markerCategoryId] && !featuredNames.has(marker.name))
  .map((marker) => {
    const x = Number(marker.x);
    const y = -Number(marker.y);
    const kind = kindByCategory[marker.markerCategoryId];
    return {
      id: 10_000 + Number(marker.id),
      name: translateMarkerName(marker.name || kind, kind),
      region: "海拉鲁参考全图",
      kind,
      x: round(((x - bounds.left) / (bounds.right - bounds.left)) * 100),
      y: round(((y - bounds.top) / (bounds.bottom - bounds.top)) * 100),
      note: marker.description?.trim() && !/[A-Za-z]/.test(marker.description)
        ? marker.description.trim()
        : `${kind}精确位置标记。`,
    };
  })
  .filter((point) => point.x >= 0 && point.x <= 100 && point.y >= 0 && point.y <= 100)
  .sort((a, b) => a.kind.localeCompare(b.kind) || a.name.localeCompare(b.name));

await writeFile(output, `${JSON.stringify(points)}\n`, "utf8");
console.log(`已生成 ${points.length} 个参考标记：${output}`);
