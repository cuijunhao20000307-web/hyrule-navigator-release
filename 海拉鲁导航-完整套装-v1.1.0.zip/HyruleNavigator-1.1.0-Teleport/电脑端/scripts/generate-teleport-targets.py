#!/usr/bin/env python3
"""Build safe landmark teleport coordinates from BOTW placement XML.

Usage:
  python3 scripts/generate-teleport-targets.py \
    /path/to/botw-tools/mubin app/teleport-targets.json

The placement layout is documented by MrCheeze/botw-tools.  Landmark object
origins are never emitted: every target is the matching in-game
DestinationAnchor intended for Link to stand on.  No game asset is copied.
"""

from __future__ import annotations

import json
import math
import sys
import xml.etree.ElementTree as ET
from pathlib import Path


X_SCALE = 0.0083668005
X_OFFSET = 50.2008033
Z_SCALE = 0.0100080063
Z_OFFSET = 50.0400322

FEATURED = [
    {"id": 1, "kind": "塔", "x": 45.507085, "y": 67.005104},
    {"id": 2, "kind": "神庙", "x": 44.574, "y": 65.188},
    {"id": 3, "kind": "神庙", "x": 53.092, "y": 60.126},
    {"id": 6, "kind": "塔", "x": 58.708, "y": 67.195},
    {"id": 7, "kind": "塔", "x": 35.515, "y": 42.291},
    {"id": 8, "kind": "塔", "x": 69.093, "y": 48.949},
]


def map_to_world(point: dict[str, object]) -> tuple[float, float]:
    return (
        (float(point["x"]) - X_OFFSET) / X_SCALE,
        (float(point["y"]) - Z_OFFSET) / Z_SCALE,
    )


def read_actors(mubin_dir: Path) -> list[tuple[float, float, float, str]]:
    actors: list[tuple[float, float, float, str]] = []
    for path in sorted(mubin_dir.glob("*.xml")):
        root = ET.parse(path).getroot()
        for actor in root.findall("./Objs/value"):
            name = actor.find("UnitConfigName")
            translation = actor.find("Translate")
            if name is None or name.text is None or translation is None:
                continue
            values = translation.findall("value")
            if len(values) != 3 or any(value.text is None for value in values):
                continue
            try:
                x, y, z = (float(value.text.removesuffix("f")) for value in values)
            except ValueError:
                continue
            actors.append((x, y, z, name.text))
    return actors


def nearest(
    actors: list[tuple[float, float, float, str]],
    x: float,
    z: float,
    predicate,
) -> tuple[float, float, float, str, float] | None:
    matches = [
        (*actor, math.hypot(actor[0] - x, actor[2] - z))
        for actor in actors
        if predicate(actor[3])
    ]
    return min(matches, key=lambda actor: actor[4]) if matches else None


def destination_anchor(
    actors: list[tuple[float, float, float, str]],
    reference: tuple[float, float, float, str] | tuple[float, float, float, str, float],
) -> tuple[float, float, float, str] | None:
    """Return the placement's safe stand point paired with a warp/terminal."""
    matches = [
        actor
        for actor in actors
        if actor[3] == "DestinationAnchor"
        and math.hypot(actor[0] - reference[0], actor[2] - reference[2]) < 5.0
        and abs(actor[1] - reference[1]) < 1.0
    ]
    if not matches:
        return None
    return min(
        matches,
        key=lambda actor: math.dist(actor[:3], reference[:3]),
    )


def target_for(
    point: dict[str, object],
    actors: list[tuple[float, float, float, str]],
) -> dict[str, object] | None:
    x, z = map_to_world(point)
    if point["kind"] == "神庙":
        warp = nearest(actors, x, z, lambda name: "WarpPoint" in name)
        if warp is None or warp[4] > 15:
            return None
        anchor = destination_anchor(actors, warp)
        if anchor is None:
            return None
        target_x, target_y, target_z = anchor[:3]
        source = "shrine_anchor"
    elif point["kind"] == "塔":
        closest = nearest(
            actors,
            x,
            z,
            lambda name: name == "FldObj_DownloadTerminalBody_A_01",
        )
        if closest is None or closest[4] > 20:
            return None
        same_tower = [
            actor
            for actor in actors
            if actor[3] == "FldObj_DownloadTerminalBody_A_01"
            and math.hypot(actor[0] - closest[0], actor[2] - closest[2]) < 1.0
        ]
        terminal = max(same_tower, key=lambda actor: actor[1])
        anchor = destination_anchor(actors, terminal)
        if anchor is None:
            return None
        target_x, target_y, target_z = anchor[:3]
        source = "tower_anchor"
    else:
        return None
    return {
        "id": int(point["id"]),
        "x": round(target_x, 3),
        "y": round(target_y, 3),
        "z": round(target_z, 3),
        "source": source,
    }


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit(
            "用法：generate-teleport-targets.py <botw-tools/mubin> <output.json>"
        )
    root = Path(__file__).resolve().parents[1]
    mubin_dir = Path(sys.argv[1])
    output = Path(sys.argv[2])
    reference = json.loads((root / "app/hyrule-markers.json").read_text("utf-8"))
    candidates = FEATURED + [
        point for point in reference if point["kind"] in {"神庙", "塔"}
    ]
    actors = read_actors(mubin_dir)
    targets = [
        target
        for point in candidates
        if (target := target_for(point, actors)) is not None
    ]
    payload = {
        "version": 1,
        "gameVersion": "1.6.0",
        "buildId": "8E9978D50BDD20B4C8395A106C27FFDE",
        "targets": sorted(targets, key=lambda target: int(target["id"])),
    }
    output.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")) + "\n",
        "utf-8",
    )
    print(f"已生成 {len(targets)} 个安全传送点：{output}")


if __name__ == "__main__":
    main()
