@echo off
chcp 65001 >nul
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo 未找到 Node.js。请先安装 Node.js 22 或更高版本。
  pause
  exit /b 1
)

if not exist node_modules (
  echo 首次启动，正在安装网页依赖……
  call npm install
  if errorlevel 1 (
    echo 依赖安装失败，请检查网络后重试。
    pause
    exit /b 1
  )
)

echo 海拉鲁导航正在启动：
echo 电脑：http://localhost:3000
echo 手机：运行 ipconfig 查看电脑 IPv4 地址，再打开 http://电脑IPv4地址:3000
echo 关闭本窗口或按 Control+C 可停止服务。
call npm run dev -- --hostname 0.0.0.0
