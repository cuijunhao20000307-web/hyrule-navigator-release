import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );
}

test("server-renders the Hyrule navigation application", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<html lang="zh-CN">/i);
  assert.match(html, /<title>海拉鲁导航｜旷野之息独立伴侣<\/title>/i);
  assert.match(html, /海拉鲁全图导航/);
  assert.match(html, /筛选标记/);
  assert.match(html, /HyruleBridgeUltra|海利亚盾/);
});

test("keeps mobile coordinates, desktop scrolling, voice navigation, and confirmed teleport wired", async () => {
  const [page, css, config, markers, teleportTargets, switchSource, dmntSource] = await Promise.all([
    readFile(new URL("../app/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
    readFile(new URL("../public/config.json", import.meta.url), "utf8"),
    readFile(new URL("../app/hyrule-markers.json", import.meta.url), "utf8"),
    readFile(new URL("../app/teleport-targets.json", import.meta.url), "utf8"),
    readFile(new URL("../work/hyrule-ultra/source/main.cpp", import.meta.url), "utf8"),
    readFile(new URL("../work/hyrule-ultra/source/dmntcht.c", import.meta.url), "utf8"),
  ]);

  assert.match(page, /className=\{`map-world /);
  assert.match(page, /className="tile-grid"/);
  assert.match(page, /function toTilePoint/);
  assert.match(page, /function worldToMapPoint/);
  assert.match(page, /function mapPointToWorld/);
  assert.match(page, /xScale: 0\.0083668005/);
  assert.match(page, /zScale: 0\.0100080063/);
  assert.doesNotMatch(page, /playerXOffset|playerYOffset/);
  assert.match(page, /map: \{ x: 45\.507085, y: 67\.005104 \}/);
  assert.match(page, /world: \{ x: -560\.9931640625, y: 246\.42724609375, z: 1695\.1500244140625/);
  assert.match(page, /初始塔模拟/);
  assert.doesNotMatch(page, /4000 - data\.z/);
  assert.match(page, /34\.25 \/ 256/);
  assert.match(page, /49\.875 \/ 256/);
  assert.match(page, /SpeechSynthesisUtterance/);
  assert.match(page, /前方约 \$\{distance\} 米/);
  assert.match(page, /"zh-CN" \| "ja-JP"/);
  assert.match(page, /播报：\{voiceLanguage === "zh-CN" \? "中文" : "日语"\}/);
  assert.match(page, /const targetWorld = mapPointToWorld\(navigationTarget\)/);
  assert.match(page, /arrived: distance < 20/);
  assert.match(page, /\/v1\/teleport/);
  assert.match(page, /\/v1\/teleport\/status/);
  assert.match(page, /特斯拉菜单“实验传送”/);
  assert.match(page, /teleportPostRef/);
  assert.match(page, /activeTeleportRequestRef/);
  assert.match(page, /window\.setTimeout\(\(\) => controller\.abort\(\), 5000\)/);
  assert.match(page, /terrainTeleportHeight/);
  assert.match(page, /botw-terrain-height\.png/);
  assert.match(page, /safe limit|安全限制为/);
  assert.doesNotMatch(page, /y:\s*selected\.y/);
  assert.match(page, /向下滚动筛选列表/);
  assert.match(page, /PageDown/);
  assert.match(page, /referenceMarkers/);
  assert.match(page, /explorationKinds/);
  assert.match(css, /\.map-world-frame\{/);
  assert.match(css, /aspect-ratio:1/);
  assert.match(css, /\.map-world\{/);
  assert.match(css, /\.sidebar-scroll\{/);
  assert.match(css, /\.list-scroll-controls\{/);
  assert.match(css, /@media\(max-width:800px\).*\.map-world-frame\{/s);
  assert.match(css, /\.marker\.current\{[^}]*box-shadow:none[^}]*animation:none/);
  assert.match(css, /\.actions \.teleport\{[^}]*grid-column:1\/-1/);
  assert.match(css, /\.teleport-banner\{/);
  assert.match(css, /\.map-world\.picking \.marker,[^{]*\{pointer-events:none\}/);
  const markerData = JSON.parse(markers);
  assert.equal(markerData.length, 1392);
  assert.equal(markerData.filter((point) => point.kind === "神庙").length, 118);
  assert.equal(markerData.filter((point) => point.kind === "呀哈哈").length, 900);
  assert.equal(markerData.filter((point) => /[A-Za-z]/.test(`${point.name}${point.region}${point.note}`)).length, 0);
  assert.equal(markerData.filter((point) => point.name === "克洛格果实").length, 900);
  assert.equal(JSON.parse(config).port, 37890);
  const targetData = JSON.parse(teleportTargets);
  assert.equal(targetData.targets.length, 135);
  assert.equal(targetData.targets.filter((target) => target.source === "shrine_anchor").length, 120);
  assert.equal(targetData.targets.filter((target) => target.source === "tower_anchor").length, 15);
  assert.deepEqual(
    targetData.targets.find((target) => target.id === 1),
    { id: 1, x: -560.993, y: 246.427, z: 1695.15, source: "tower_anchor" },
  );
  assert.notEqual(targetData.targets.find((target) => target.id === 1).y, 67.002235);
  assert.match(switchSource, /TeleportState::Pending/);
  assert.match(switchSource, /MaxTeleportDistance=500\.0f/);
  assert.match(switchSource, /HavokRootOffset=0x02D37AF0/);
  assert.match(switchSource, /MatrixRootOffset=0x02CA1140/);
  assert.match(switchSource, /confirmTeleport\(\)/);
  assert.match(switchSource, /readPlayerTransformSnapshot/);
  assert.match(switchSource, /getLiveMatchingMetadata/);
  assert.match(switchSource, /activeClientFd/);
  assert.match(dmntSource, /65103/);
});
