#!/bin/zsh
set -e

cd "$(dirname "$0")"

CODEX_NODE="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
if ! command -v node >/dev/null 2>&1 && [ -x "$CODEX_NODE" ]; then
  export PATH="$(dirname "$CODEX_NODE"):$PATH"
fi

if ! command -v node >/dev/null 2>&1; then
  echo "未找到 Node.js。请先安装 Node.js 22 或更高版本。"
  read -r "?按回车键关闭窗口..."
  exit 1
fi

if [ ! -d node_modules ]; then
  if ! command -v npm >/dev/null 2>&1; then
    echo "首次启动需要 npm。请安装 Node.js 22 或更高版本后重试。"
    read -r "?按回车键关闭窗口..."
    exit 1
  fi
  echo "首次启动，正在安装网页依赖..."
  npm install
fi

LAN_IP="$(ipconfig getifaddr en0 2>/dev/null || ipconfig getifaddr en1 2>/dev/null || true)"

echo "海拉鲁导航正在启动："
echo "电脑：http://localhost:3000"
if [ -n "$LAN_IP" ]; then
  echo "手机：http://${LAN_IP}:3000"
else
  echo "手机：请在系统网络设置中查看电脑 IP，再打开 http://电脑IP:3000"
fi
echo "关闭本窗口或按 Control+C 可停止服务。"
export WRANGLER_LOG_PATH=.wrangler/wrangler.log
if command -v npm >/dev/null 2>&1; then
  npm run dev -- --hostname 0.0.0.0
else
  ./node_modules/.bin/vinext dev --hostname 0.0.0.0
fi
